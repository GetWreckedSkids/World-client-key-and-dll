1. Run the MelonLoader Installer
2. Choose the VRChat.exe file in Steam\steamapps\common\VRChat
3. Leave everything "auto" and "latest"
4. Click Install
5. Move the all the files into the same file path as above. (you dont need the anit crash and if you already have avis blacklisted dont drag over the WorldClient File)

====== Other ======
6a. IF the game is frozen, or you hear a beep, check your MelonLoader Console
6b. If said above is a thing, more than likely there needs to be an update, check #𝖀pdate-ᴋeys for the key. 
6c. If update loops check #𝖀pdates